
.. _continuous-ksone:

KSone Distribution
==================

Implementation: `scipy.stats.ksone`
