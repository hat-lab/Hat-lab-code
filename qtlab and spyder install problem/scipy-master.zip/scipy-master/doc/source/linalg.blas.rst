.. automodule:: scipy.linalg.blas
