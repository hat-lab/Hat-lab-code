.. automodule:: scipy.spatial.distance
