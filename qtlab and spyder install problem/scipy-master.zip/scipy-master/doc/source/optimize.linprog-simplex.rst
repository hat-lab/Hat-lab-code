.. _optimize.linprog-simplex:

linprog(method='Simplex')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_simplex
   :method: simplex
